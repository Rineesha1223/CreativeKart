import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems = [];
  retrieveData: any;
  orders: any;
  orderDetails: any;
  total = 0;
  value = 1;

  constructor(private service: CustService, private router: Router) {
    this.cartItems = this.service.cartItems;
  }

  ngOnInit(): void {
    this.orders = {};
    this.orderDetails = {product: {}};
    this.findTotal();
  }

    remove(product: any) {
      console.log("Remove me..")
      this.service.remove(product);
      this.findTotal();
    }

  purchase() {
    this.router.navigate(['purchase']);
  }

  findTotal() {
    this.total = 0;
      for (let index = 0; index < this.cartItems.length; index++) {
        this.total += this.cartItems[index].price * this.value;
      }
  }

  decrementValue(index:number) {
    if (this.value == 1) {
      this.value=1;
    }
    else {
      this.value--;
      this.findTotal();
    }
  }

  incrementValue(index:number) {
    this.value++;
    this.findTotal();
  }

  navi() {
    this.router.navigate(['show']);
  }
}
