import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  user : any;
  
  constructor() {
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log("View   " + this.user.email)
   }

  ngOnInit(): void {
  }

}
