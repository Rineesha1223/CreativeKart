import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  products = [];
  user: any;

  constructor(public service: CustService, private router: Router) {
    this.user = localStorage.getItem('customer');
    console.log(this.user);
   }

  
  ngOnInit(): void {
    this.service.getForCart().subscribe(result => this.products.push(result));
  }

  logout() {
    this.service.setUserLoggedOut();
    this.router.navigate(['login']);
  }

}
