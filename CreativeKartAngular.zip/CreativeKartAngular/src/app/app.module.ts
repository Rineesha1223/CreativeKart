import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MainComponent } from './main/main.component';
import { AuthGuard } from './auth.guard';
import { UploadImagesComponent } from './upload-images/upload-images.component';
import { ShowDbImagesComponent } from './show-db-images/show-db-images.component';
import { CartComponent } from './cart/cart.component';
import { PurchaseComponent } from './purchase/purchase.component';
import { ViewComponent } from './view/view.component';
import { EditComponent } from './edit/edit.component';


const appRoot: Routes = [{path: '', component: LoginComponent},
                          {path: 'login', component: LoginComponent},
                          {path: 'home', component: HomeComponent},
                          {path: 'show', component: ShowDbImagesComponent},
                          {path: 'upload', component: UploadImagesComponent},
                          {path: 'register', component: RegisterComponent},
                          {path: 'cart', component: CartComponent},
                          {path: 'purchase', component: PurchaseComponent},
                          {path: 'view', component: ViewComponent},
                          {path: 'edit', component: EditComponent}];

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HomeComponent,
    LoginComponent,
    MainComponent,
    UploadImagesComponent,
    ShowDbImagesComponent,
    CartComponent,
    PurchaseComponent,
    ViewComponent,
    EditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoot),
    HttpClientModule,
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
