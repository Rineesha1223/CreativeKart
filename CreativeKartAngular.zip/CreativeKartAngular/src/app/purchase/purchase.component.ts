import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Router } from '@angular/router';
import { CartComponent } from '../cart/cart.component';
import {formatDate} from '@angular/common';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css']
})
export class PurchaseComponent implements OnInit {
  cartItems = [];
  value = 0;
  total = 0;
  orderedDate: any;
  constructor(private service: CustService, private router: Router) {

   }

  ngOnInit(): void {
    let cart = new CartComponent(this.service, this.router);
    this.cartItems = cart.cartItems;
    this.value = cart.value;
    cart.findTotal();
    this.total = cart.total;
  }

  editcart() {
    this.router.navigate(['cart']);
  }

  OnSubmit(deliveryForm: any){
   

    
    
    //this.orderedDate = formatDate(new Date(), 'yyyy/MM/dd', 'en');;
    let deliveryAddress = deliveryForm.address; 
    let phoneNo = deliveryForm.phoneNo;
    let totalPrice = this.total;
    console.log(this.orderedDate, deliveryAddress, phoneNo, totalPrice);
    this.service.confirmOrder(deliveryAddress, phoneNo, totalPrice).subscribe((result: any) => { console.log(result); });
    //this.toastr.success('Successfully','Order Placed', {timeOut:2000});
    alert("Ordered Placed");
    this.service.removeItemsFromCart();
 
  }

}
