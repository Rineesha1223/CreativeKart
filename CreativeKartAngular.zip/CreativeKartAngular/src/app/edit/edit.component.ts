import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  customer: any;
  constructor(private router: Router, private service : CustService) {
    this.customer = {customerId : '', firstName : '', lastName : '', email : '', street : '', city : '', 
    state :'', phoneNo : '', password : ''
  }
   }

  ngOnInit(): void {
  }

  update(): void {
    this.service.updateCust(this.customer).subscribe((result: any) => { 
    this.router.navigate(['show']);
  } );
  }

  nav() {
    this.router.navigate(['show']);
  }

}
