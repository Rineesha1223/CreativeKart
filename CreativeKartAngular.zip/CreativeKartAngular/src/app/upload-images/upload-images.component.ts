import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload-images',
  templateUrl: './upload-images.component.html',
  styleUrls: ['./upload-images.component.css']
})
export class UploadImagesComponent implements OnInit {
  imageUrl: string;
  fileToUpload: File = null;;
  reader: FileReader;
  constructor(private service: CustService, private router: Router) {
    this.imageUrl = '/assets/images/upload1.jpg';
  }

  ngOnInit() {
    
  }

  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    this.service.postFile(imageForm, this.fileToUpload).subscribe (
      data => {
        console.log('done');
        this.imageUrl = '/assets/images/shirt.jpg';
        this.router.navigate(['show']);
      }
    );
  }


  // handleFileInput(file: FileList) {
  //   this.fileToUpload = file.item(0);

  //   // Show image preview
  //   this.reader = new FileReader();
  //   this.reader.readAsDataURL(this.fileToUpload);
  //   this.reader.onload = (event: any) => {
  //     this.imageUrl = event.target.result;
  //   };
  // }

  // OnSubmit(imageForm: any) {
  //  this.service.postFile(imageForm, this.fileToUpload).subscribe(
  //    data => {
  //      console.log('done');
  //      this.imageUrl = '/assets/image/default.png';
  //    }
  //  );
  // }
}
