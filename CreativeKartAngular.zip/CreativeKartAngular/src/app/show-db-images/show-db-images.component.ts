import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';

@Component({
  selector: 'app-show-db-images',
  templateUrl: './show-db-images.component.html',
  styleUrls: ['./show-db-images.component.css']
})
export class ShowDbImagesComponent implements OnInit {

  products: any;
  constructor(private service: CustService) { }

  ngOnInit() {
    this.service.getProducts().subscribe( (result: any) => {console.log(result); this.products = result; });
  }
  addToCart(product: any) {
    this.service.addToCart(product);
  }
}
