import { Component, Input, OnInit } from '@angular/core';
import { CustService } from '../cust.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @Input() customerName: any;
  @Input() email: any;
  constructor(private service : CustService) {
    this.customerName = localStorage.getItem('customer');
    console.log("HomeComponent" + this.customerName);
  }

  ngOnInit(): void {
  }

}
