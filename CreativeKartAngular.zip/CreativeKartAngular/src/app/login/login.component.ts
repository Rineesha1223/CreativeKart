import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Router } from '@angular/router';
import { ViewChild,ElementRef } from '@angular/core'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  user: any;
  auth2:any;
  constructor(private router: Router, private custService: CustService) {
    this.googleInitialize();
    this.user = {loginId: '', password: ''};
  }

  ngOnInit(): void {
    
  }

  loginSubmit(loginForm: any): void {
    this.custService.loginCust(this.user).subscribe((result: any) => { console.log(result); 
    if (result != null) {
      this.custService.setUserLoggedIn();
      localStorage.setItem('customer', result.firstName);
      localStorage.setItem('user', JSON.stringify(result));
      this.router.navigate(['show']);
    } else {
      alert('Invalid Credentials..');
    }
    console.log(loginForm);
  } )
  }

  nav() {
    this.router.navigate(['register']);
  }

  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '962861631365-83ojspkqfe3v00cij8p8hke5lhr7uuks.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        this.custService.loginCustByEmail(profile.getEmail()).subscribe((result: any) => { console.log("Result"  + result); 
          if (result != null) {
            this.custService.setUserLoggedIn();
            localStorage.setItem('customer', result.firstName);
            localStorage.setItem('user', JSON.stringify(result));
            this.router.navigate(['show']);
          } else {
            alert('Invalid Email..');
          }
        } )
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }
  
}
