import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustService {
  isUserLogged: boolean;
  cartItems = [];
  productToBeAdded: Subject<any>;

  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
    this.productToBeAdded = new Subject();
   }

   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
  
   registerCust(customer: any) {
     console.log('Inside service');
     console.log(customer);
    return this.httpClient.post('Creative_Kart_App/webapi/myresource/registerCust/',customer);
   }
   updateCust(customer: any) {
    return this.httpClient.post('Creative_Kart_App/webapi/myresource/updateCust/',customer);
   }
   loginCust(user: any) {
    return this.httpClient.get('Creative_Kart_App/webapi/myresource/getCustByUserPass/' + user.loginId + '/' + user.password);
   }
   loginCustByEmail(email: any) {
    return this.httpClient.get('Creative_Kart_App/webapi/myresource/getCustByEmail/' + email);
   }
   addToCart(product: any) {
     if (this.cartItems.includes(product)) {
       alert("This has already added to cart");
     }
     else {
    this.productToBeAdded.next(product);
    this.cartItems.push(product);
     }
    // localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
  }

  remove(product: any) {
    console.log("length", this.cartItems.length);
    
    this.cartItems.splice(this.cartItems.indexOf(product),1);
    console.log(this.cartItems);
  }

  removeItemsFromCart() {
   this.cartItems = []; 
  }

  getForCart() {
    return this.productToBeAdded.asObservable();
  }

  postFile(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    console.log("imageform", ImageForm, "file", fileToUpload)
    const formData: FormData = new FormData();
    formData.append('productImage', fileToUpload, fileToUpload.name);
    formData.append('productName', ImageForm.productName);
    formData.append('price', ImageForm.price);
    formData.append('quantity', ImageForm.quantity);
    formData.append('category', ImageForm.category);
    console.log("formdata:", formData);
    return this.httpClient.post('Creative_Kart_App/webapi/myresource/uploadImage', formData);
  }

  confirmOrder( deliveryAddress, phoneNo, totalPrice) : any{

    const formData: FormData = new FormData();
    formData.append('deliveryAddress', deliveryAddress);
   // formData.append('orderedDate', orderedDate);
    //formData.append('phoneNo', phoneNo);
    formData.append('totalPrice', totalPrice);
    console.log("Form Data.."+formData);
    return this.httpClient.post('Creative_Kart_App/webapi/myresource/confirmOrder', formData);
    
  }
  
   //getImage(): Observable<File> {
    //console.log('Inside Service...');
   // return this.httpClient.get('Creative_Kart/webapi/myresource/downloadImage', { responseType: 'blob' });
   //}
   getProducts() {
   return this.httpClient.get('Creative_Kart_App/webapi/myresource/getProducts').pipe(retry(10));
   }

   purchase(product: any) {
    return this.httpClient.post('Creative_Kart_App/webapi/myresource/purchase', product);
   }

  sendMail(email:any) {
    return this.httpClient.get('Creative_Kart_App/webapi/myresource/mail/' + email);
  }

}
